<?php
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}
$lista = $_GET['lista']; //email | senha 
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~",";");
$explode = multiexplode($separadores,$lista);

$cpf = $explode[0];

 

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://auxilio.caixa.gov.br/api/CaixaTem");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
"Content-Type: application/json; charset=utf-8",
"Host: auxilio.caixa.gov.br",
"Connection: Keep-Alive",
"Accept-Encoding: gzip",
"User-Agent: okhttp/3.4.2"
,));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"cpf":'.$cpf.'}');
$auxilio = curl_exec($ch);

if (strpos($auxilio, 'CADUN') == true) {
	echo '<font color=lime>Aprovada &#10004;</font>Cpf Live '.$cpf.'</font> <br>';
}
elseif (strpos($auxilio, 'CPF em situação divergente') ==true) {
	echo '<font color=red>Reprovada &#10008;</font> Cpf Die '.$cpf.'</font> <br>';
}
elseif (strpos($auxilio, 'Usuário liberado') ==true) {
	echo '<font color=lime>Aprovada &#10004;</font>Cpf Live '.$cpf.'</font> <br>';
}
elseif (strpos($auxilio, 'Erro de serviço') ==true) {
	echo '<font color=red>Reprovada &#10008;</font> Cpf Invalido '.$cpf.'</font> <br>';
}
else{
	echo '<font color=red>Reprovada &#10008;</font> Cpf Die '.$cpf.' Motivo Desconhecido</font> <br>';
	echo "$auxilio";
}

  ?>

