<?php

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://login2.caixa.gov.br/auth/realms/internet/login-actions/authenticate?session_code=aSa2KpZZr8XvAVwTQ5AyCJOcMJRJhDzdDfoY0qv_y2w&execution=8474e958-e12f-438b-8da6-73b4bb3574ff&client_id=cli-mob-nbm&tab_id=cOwwWIF7JWA");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
"Host: login2.caixa.gov.br",
"Connection: keep-alive",
"Cache-Control: max-age=0",
"Origin: https://login2.caixa.gov.br",
"Upgrade-Insecure-Requests: 1"
// "Content-Type: application/x-www-form-urlencoded",
// "User-Agent: Mozilla/5.0 (Linux; Android 5.1.1; SM-G955N Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.136 Mobile Safari/537.36",
// "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
// "Referer: https://login2.caixa.gov.br/auth/realms/internet/login-actions/authenticate?execution=8474e958-e12f-438b-8da6-73b4bb3574ff&client_id=cli-mob-nbm&tab_id=cOwwWIF7JWA",
// "Accept-Encoding: gzip, deflate",
// "Accept-Language: en-US,en;q=0.9",
// "Cookie: AUTH_SESSION_ID=71ab5fc5-931b-4c16-9ce1-9026441e083a.AZRJPCAPLLX006; KC_RESTART=eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyOGYxZTFlZC02ZDAxLTRkMDAtYWEzMS1lM2VlY2MzY2RhYmIifQ.eyJjaWQiOiJjbGktbW9iLW5ibSIsInB0eSI6Im9wZW5pZC1jb25uZWN0IiwicnVyaSI6ImJyLmdvdi5jYWl4YS50ZW06L29hdXRoMkNhbGxiYWNrIiwiYWN0IjoiQVVUSEVOVElDQVRFIiwibm90ZXMiOnsiaXNzIjoiaHR0cHM6Ly9sb2dpbjIuY2FpeGEuZ292LmJyL2F1dGgvcmVhbG1zL2ludGVybmV0IiwicmVzcG9uc2VfdHlwZSI6ImNvZGUiLCJjb2RlX2NoYWxsZW5nZV9tZXRob2QiOiJTMjU2IiwibG9naW5faGludCI6IjAwMDI2MjY4MTA4IiwiY2xpZW50X3JlcXVlc3RfcGFyYW1fYXBwIjoiYnIuZ292LmNhaXhhLnRlbTt2ZXJ0aWNhbD1odHRwczovL21vYmlsaWRhZGUuY2xvdWQuY2FpeGEuZ292LmJyO3J1bnRpbWU9bWZwIiwic2NvcGUiOiJvZmZsaW5lX2FjY2VzcyIsImNsaWVudF9yZXF1ZXN0X3BhcmFtX2RldmljZUlkIjoiNDFjMDg4NjQtZTFmZS0zMTIyLWE1MWEtZDE1ZTJkYjQ0N2M2IiwiY2xpZW50X3JlcXVlc3RfcGFyYW1fc28iOiJBbmRyb2lkIiwiY2xpZW50X3JlcXVlc3RfcGFyYW1fbml2ZWwiOiIxMCIsInN0YXRlIjoiODloUnlsUExOSGZmR09IOG9Gdmh0dyIsInJlZGlyZWN0X3VyaSI6ImJyLmdvdi5jYWl4YS50ZW06L29hdXRoMkNhbGxiYWNrIiwiY2xpZW50X3JlcXVlc3RfcGFyYW1fb3JpZ2VtIjoibWYiLCJjb2RlX2NoYWxsZW5nZSI6IjZ6WVdxVDB1Q1pkYWVEYlYyaDRBcFItQWhqMTR2eEFfQlZlMkszb1VjbWcifX0.Msn-rFhGXY7tHynrTzMUoZBGRPmCYT2qkSeCG4IucN4; ApplicationGatewayAffinity03CORS=13a56995bcc1a942ec87851c5cd45c44; ApplicationGatewayAffinity03=13a56995bcc1a942ec87851c5cd45c44; ROUTEID=.AZRJPCAPLLX015; ASLBSA=03cfbd01481b45fd7bf48cf3dcb4ecdf11d36e6013119309a2811fe9da7d03ae; ASLBSACORS=03cfbd01481b45fd7bf48cf3dcb4ecdf11d36e6013119309a2811fe9da7d03ae",
// "X-Requested-With: com.android.browser"
,));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POSTFIELDS, 'f10=&fingerprint=bbe05027098e65243cdf93229d8aaead&step=1&username=00026268108');
$auxilio = curl_exec($ch);
print_r($auxilio);

  ?>

